<?php

define('TITLE', "Home");
include '../assets/layouts/header.php';
    include '../assets/layouts/footer.php'

    ?>